package edu.neu.info6205.abs;

import java.util.ArrayList;

/**
 * The Interface SelectionHandler.
 */
public interface SelectionHandler {

	public ArrayList<Chromosome> select(ArrayList<Chromosome> chromos);
}
