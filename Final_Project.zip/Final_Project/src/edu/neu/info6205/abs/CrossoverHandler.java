package edu.neu.info6205.abs;

/**
 * The Interface CrossoverHandler.
 */
public interface CrossoverHandler {

	public void crossover(Chromosome chrom1, Chromosome chrom2);
}
