package edu.neu.info6205.abs;

/**
 * The Interface MutationHandler.
 */
public interface MutationHandler {

	public void mutate(Chromosome chrom);
	
}
